from setuptools import setup

setup(
    name='hellobalazs',
    version='0.0.2',
    description='Say hello!',
    py_modules=["hellobalazs"],
    package_dir={'': 'src'},
)